﻿using App.Data.Infrastructure;
using System;
using System.Collections.Generic;
using System.Text;

namespace App.Data
{
    public class AppDatabaseFactory : IDatabaseFactory
    {
        public IDatabase Create()
        {
            return new AppDatabase();
        }
    }
}
