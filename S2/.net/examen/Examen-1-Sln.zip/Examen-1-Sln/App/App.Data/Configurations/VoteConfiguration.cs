﻿using App.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace App.Data.Configurations
{
    class VoteConfiguration : IEntityTypeConfiguration<Vote>
    {
        public void Configure(EntityTypeBuilder<Vote> builder)
        {
            builder.HasOne(e => e.Election).WithMany(e => e.Votes).HasForeignKey(e => e.DateElection);
            builder.HasOne(e => e.PartiePolitique).WithMany(e => e.Votes).HasForeignKey(e => e.PartiePolitiqueId);
            builder.HasKey(e => new { e.DateElection, e.PartiePolitiqueId, e.VoteId });
        }
    }
}
