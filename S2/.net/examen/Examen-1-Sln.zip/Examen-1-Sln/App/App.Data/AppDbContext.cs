﻿using App.Data.Configurations;
using App.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace App.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<Electeur> Electeurs { get; set; }
        public DbSet<Election> Elections { get; set; }
        public DbSet<PartiePolitique> PartiePolitiques { get; set; }
        public DbSet<Vote> Votes { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json", true, true).Build();

            optionsBuilder.
                UseLazyLoadingProxies().
                UseSqlServer(config["ConnectionStrings:Default"]);
            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            var properties = modelBuilder.Model.GetEntityTypes().
                SelectMany(t => t.GetProperties()).
                Where(p => p.ClrType == typeof(DateTime));

            foreach (var p in properties)
            {
                p.SetDefaultValue(new DateTime(1950, 3, 20));
            }

            modelBuilder.ApplyConfiguration(new VoteConfiguration());
            modelBuilder.ApplyConfiguration(new ElectionConfiguration());

            base.OnModelCreating(modelBuilder);
        }
    }
}
