﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace App.Domain
{
    public class Electeur
    {
        [Required]
        [MinLength(8)]
        [MaxLength(8)]
        [RegularExpression("[0-9]+")]
        public string CIN { get; set; }
        public DateTime DateNaissance { get; set; }
        public int ElecteurId { get; set; }
        public BureauVote MonBureauVote { get; set; }
        public Genre MonGenre { get; set; }
        public virtual IList<Election> Elections { get; set; }
    }
}
