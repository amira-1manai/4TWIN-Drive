﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App.Domain
{
    public class Vote
    {
        public DateTime DateElection { get; set; }
        public DateTime DateVote { get; set; }
        public string MonBureauVote { get; set; }
        public int PartiePolitiqueId { get; set; }
        public int VoteId { get; set; }
        public virtual Election Election { get; set; }
        public virtual PartiePolitique PartiePolitique { get; set; }
    }
}
