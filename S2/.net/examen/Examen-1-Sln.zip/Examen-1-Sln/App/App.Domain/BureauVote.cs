﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace App.Domain
{
    [Owned]
    public class BureauVote
    {
        public string Ville { get; set; }
        public string Gouvernorat { get; set; }
        public string Ecole { get; set; }
        public int NumSalle { get; set; }
    }
}
