﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App.Domain
{
    public enum Genre
    {
        Femme,
        Homme
    }
}
