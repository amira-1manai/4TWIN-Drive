﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace App.Domain
{
    public class Election
    {
        [Key]
        public DateTime DateElection { get; set; }
        public TypeElection MonTypeElection { get; set; }
        public virtual IList<Electeur> Electeurs { get; set; }
        public virtual IList<Vote> Votes { get; set; }
    }
}
