﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App.Domain
{
    public enum TypeElection
    {
        Parlementaire,
        Presidentielle1,
        Presidentielle2
    }
}
