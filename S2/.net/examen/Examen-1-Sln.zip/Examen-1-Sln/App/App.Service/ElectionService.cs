﻿using App.Data.Infrastructure;
using App.Domain;
using App.Service.Infrastructure;
using GP.Service.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;

namespace GP.Service
{
    public class ElectionService : ServiceBase<Election>, IElectionService
    {
        public ElectionService(IUnitOfWork unitOfWork) : base(unitOfWork)
        { }
        public int GetElecteursCount(DateTime dateElection)
        {
            return GetMany(e => e.DateElection == dateElection).Single().Electeurs.Count;
        }
        public float GetElecteursJeunesPercent(DateTime dateElection)
        {
            int electeursJeunesCount = GetMany(e => e.DateElection == dateElection).
                Single().Electeurs.
                Where(e =>
                {
                    double age = (DateTime.Now - e.DateNaissance).TotalDays / 365;
                    return age >= 18 && age <= 35;
                }).Count();

            return (electeursJeunesCount / (float)GetElecteursCount(dateElection)) * 100;
        }
    }
}
