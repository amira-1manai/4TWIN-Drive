﻿using App.Domain;
using App.Service.Infrastructure;
using System;
using System.Collections.Generic;

namespace GP.Service.Infrastructure
{
    public interface IElectionService : IService<Election>
    {
        int GetElecteursCount(DateTime dateElection);
        float GetElecteursJeunesPercent(DateTime dateElection);
    }
}
