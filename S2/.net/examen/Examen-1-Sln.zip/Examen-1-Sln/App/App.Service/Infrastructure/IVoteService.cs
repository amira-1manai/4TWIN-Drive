﻿using App.Domain;
using App.Service.Infrastructure;
using System;
using System.Collections.Generic;

namespace GP.Service.Infrastructure
{
    public interface IVoteService : IService<Vote>
    {
        PartiePolitique GetPartiePolitiqueElu(DateTime dateElection);
    }
}
