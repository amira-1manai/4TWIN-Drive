﻿using App.Data.Infrastructure;
using App.Domain;
using App.Service.Infrastructure;
using GP.Service.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;

namespace GP.Service
{
    public class VoteService : ServiceBase<Vote>, IVoteService
    {
        public VoteService(IUnitOfWork unitOfWork) : base(unitOfWork)
        { }
        public PartiePolitique GetPartiePolitiqueElu(DateTime dateElection)
        {
            var goupByPartiePolitique = GetMany(e => e.DateElection == dateElection).GroupBy(e => e.PartiePolitiqueId);
            var partiePolitiqueEluId = goupByPartiePolitique.OrderByDescending(e => e.Count()).FirstOrDefault().Key;

            return UnitOfWork.GetRepository<PartiePolitique>().GetById(partiePolitiqueEluId);
        }
    }
}
