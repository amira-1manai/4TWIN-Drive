﻿using App.Data.Infrastructure;
using App.Domain;
using App.Service.Infrastructure;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace App.Web.Controllers
{
    public class ElecteurController : Controller
    {
        IUnitOfWork unitOfWork;
        IService<Electeur> electeurService;
        public ElecteurController(IUnitOfWork unitOfWork, IService<Electeur> electeurService)
        {
            this.unitOfWork = unitOfWork;
            this.electeurService = electeurService;
        }
        // GET: ElecteurController
        public ActionResult Index()
        {
            return View(electeurService.GetAll());
        }

        [HttpPost]
        public ActionResult Index(string filtre)
        {
            IEnumerable<Electeur> list;

            if (string.IsNullOrEmpty(filtre))
            {
                list = electeurService.GetAll();
            }
            else
            {
                list = electeurService.GetMany(e => e.CIN != null && e.CIN.ToUpper().Contains(filtre));
            }

            return View(list);
        }

        // GET: ElecteurController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: ElecteurController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ElecteurController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Electeur electeur)
        {
            try
            {
                electeurService.Add(electeur);
                unitOfWork.Commit();

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ElecteurController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: ElecteurController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ElecteurController/Delete/5
        public ActionResult Delete(int id)
        {
            return View(electeurService.GetById(id));
        }

        // POST: ElecteurController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, Electeur electeur)
        {
            try
            {
                electeurService.Delete(electeurService.GetById(id));
                unitOfWork.Commit();

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
